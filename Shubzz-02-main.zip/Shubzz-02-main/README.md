
<h1 align="center">Hey there, I'm Shubzz<img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px"></h1>

<h3 align="center">Software Engineer, Bug Bounty Hunter, a learner</h3>

<br>


<p>
  
  ## **Know Me**
  
- A Computer nerd. 🖥️
- JAVA developer but can learn and code in any language/framework.
- Die hard fan of Linux.
- A problem solver, just give me log file and access to shell and I can solve any problem. 
- Love to travel and obsessed with hiking on mountains .   🧗
- Obsessed with Reverse engineering and Assembly language . ✅
- Seeking opportunities to work in a challenging environments and push my boundaries. 💪
</p>

<div align="center">

  
 
<h3 align="left">Profile Views: 🧐</h3>
  
![](https://komarev.com/ghpvc/?username=Shubzz-02&label=PROFILE+VIEWS)
